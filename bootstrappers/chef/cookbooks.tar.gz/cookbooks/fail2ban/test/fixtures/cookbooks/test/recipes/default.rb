apt_update

include_recipe 'openssh'
include_recipe 'rsyslog'
include_recipe 'fail2ban'
