name 'test'
version '0.1.0'

depends 'openssh'
depends 'fail2ban'
depends 'rsyslog', '> 4.0.0'
