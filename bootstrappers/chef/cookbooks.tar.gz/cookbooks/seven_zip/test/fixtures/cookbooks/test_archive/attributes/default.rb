default['test_archive']['source']    = 'https://www.7-zip.org/a/7z1805-src.7z'
default['test_archive']['overwrite'] = true
default['test_archive']['checksum']  = 'd9acfcbbdcad078435586e00f73909358ed8d714d106e064dcba52fa73e75d83'
