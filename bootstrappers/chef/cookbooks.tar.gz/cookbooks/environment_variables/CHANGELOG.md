chef-environment-variables CHANGELOG
====================================

This file is used to list changes made in each version of the chef-environment-variables cookbook.

0.1.0
-----
- [Chris Gunther] - Initial release of chef-environment-variables
