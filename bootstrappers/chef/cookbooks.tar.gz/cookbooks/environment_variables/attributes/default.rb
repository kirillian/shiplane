#
# Cookbook Name:: environment_variables
#
# Copyright 2014, Room 118 Solutions
#
# All rights reserved - Do Not Redistribute
#

default['environment_variables'] = {}
