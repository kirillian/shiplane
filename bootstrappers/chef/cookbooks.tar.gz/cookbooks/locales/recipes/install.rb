execute 'locale-gen' do
  action :nothing
end
