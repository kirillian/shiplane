
locales 'de_AT.utf8' do
  action :add
end
