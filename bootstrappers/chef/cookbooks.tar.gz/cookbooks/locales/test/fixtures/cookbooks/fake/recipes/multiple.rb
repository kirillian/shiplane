locales 'multiple locales' do
  locales ['fr_FR.utf8', 'fr_BE.utf8', 'fr_CA.utf8']
end
