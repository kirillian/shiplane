name 'fake'
version '1.0.0'

depends 'locales'
