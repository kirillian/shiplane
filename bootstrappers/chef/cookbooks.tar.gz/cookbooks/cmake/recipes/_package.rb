#
# Cookbook:: cmake
# Recipe:: _package
#

package "cmake"
