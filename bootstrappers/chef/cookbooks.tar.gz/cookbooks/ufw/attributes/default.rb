default['firewall']['rules'] = []
default['firewall']['securitylevel'] = ''
default['firewall']['allow_ssh'] = true
